window.TIMELINE = {
 "lanes": [
  {
   "issue": 2,
   "title": "Project scaffold, domain model, storage with audit, and token authentication",
   "events": [
    {
     "at": "2026-09-21T14:17:34Z",
     "kind": "labeled",
     "text": "type:task"
    },
    {
     "at": "2026-09-21T14:18:36Z",
     "kind": "labeled",
     "text": "area:api"
    },
    {
     "at": "2026-09-21T14:18:36Z",
     "kind": "labeled",
     "text": "size:L"
    },
    {
     "at": "2026-09-21T14:18:36Z",
     "kind": "labeled",
     "text": "risk:high"
    },
    {
     "at": "2026-09-21T14:18:36Z",
     "kind": "labeled",
     "text": "pipeline:build"
    },
    {
     "at": "2026-09-21T14:26:34Z",
     "kind": "design",
     "text": "## 🏛 Design — #2 scaffold, domain model, storage + audit, token auth\n\n`main` read at `bb6"
    },
    {
     "at": "2026-09-21T14:45:46Z",
     "kind": "commit",
     "text": "feat(api): project scaffold, domain model, organisation-scoped storage with audit, and tok",
     "sha": "cd2ae26"
    },
    {
     "at": "2026-09-21T14:49:28Z",
     "kind": "commit",
     "text": "docs(api): D-019…D-022, the D-016/D-017 addenda, G-016, M-001's first data point",
     "sha": "36941af"
    },
    {
     "at": "2026-09-21T14:51:30Z",
     "kind": "pr",
     "text": "feat(api): scaffold, domain model, organisation-scoped storage with audit, and token auth "
    },
    {
     "at": "2026-09-21T14:56:13Z",
     "kind": "review",
     "text": "VERDICT: findings (0 red, 4 nits)",
     "red": false
    },
    {
     "at": "2026-09-21T14:56:59Z",
     "kind": "review",
     "text": "VERDICT: findings (1 red, 5 nits)",
     "red": true
    },
    {
     "at": "2026-09-21T15:04:07Z",
     "kind": "commit",
     "text": "fix(api): canonical token signatures, organisation-scoped audit writes, safe-integer round",
     "sha": "9e29d6b"
    },
    {
     "at": "2026-09-21T15:05:50Z",
     "kind": "fix-round",
     "text": "<!-- claude-fix-round -->🔁 Fix round 1/2 (in-chat)."
    },
    {
     "at": "2026-09-21T15:07:25Z",
     "kind": "review",
     "text": "VERDICT: clean",
     "red": false
    },
    {
     "at": "2026-09-21T15:07:52Z",
     "kind": "review",
     "text": "VERDICT: findings (0 red, 2 nits)",
     "red": false
    },
    {
     "at": "2026-09-21T15:08:51Z",
     "kind": "commit",
     "text": "fix(config): frozen key view hands itself to forEach callbacks, not the live Map (security",
     "sha": "a1e0201"
    },
    {
     "at": "2026-09-21T15:08:57Z",
     "kind": "merged",
     "text": "PR #7 merged"
    }
   ],
   "tests": 99
  },
  {
   "issue": 3,
   "title": "Approval rules and the requisition lifecycle API",
   "events": [
    {
     "at": "2026-09-21T14:17:35Z",
     "kind": "labeled",
     "text": "type:task"
    },
    {
     "at": "2026-09-21T14:18:26Z",
     "kind": "labeled",
     "text": "area:api"
    },
    {
     "at": "2026-09-21T14:18:27Z",
     "kind": "labeled",
     "text": "size:L"
    },
    {
     "at": "2026-09-21T14:18:27Z",
     "kind": "labeled",
     "text": "risk:high"
    },
    {
     "at": "2026-09-21T14:18:27Z",
     "kind": "labeled",
     "text": "blocked"
    },
    {
     "at": "2026-09-21T15:10:28Z",
     "kind": "labeled",
     "text": "pipeline:build"
    },
    {
     "at": "2026-09-21T15:19:50Z",
     "kind": "design",
     "text": "## 🏛 Design — approval rules and the requisition lifecycle API (#3)\n\nRead against `main` "
    },
    {
     "at": "2026-09-21T15:33:26Z",
     "kind": "commit",
     "text": "feat(api): the rule matcher, the lifecycle table, the requisition service and the HTTP pip",
     "sha": "5775cac"
    },
    {
     "at": "2026-09-21T15:45:50Z",
     "kind": "commit",
     "text": "test(api): the domain, service, idempotency, authority and tenancy suites",
     "sha": "c3a8484"
    },
    {
     "at": "2026-09-21T15:47:35Z",
     "kind": "commit",
     "text": "test(api): pin that awaiting_me never queues a buyer their own requisition",
     "sha": "b7a6a64"
    },
    {
     "at": "2026-09-21T15:48:55Z",
     "kind": "commit",
     "text": "docs: D-023, D-024, the D-008/D-009/D-010 addenda, G-017…G-019 and the API section",
     "sha": "7e0bd94"
    },
    {
     "at": "2026-09-21T15:50:03Z",
     "kind": "pr",
     "text": "Approval rules and the requisition lifecycle API"
    },
    {
     "at": "2026-09-21T15:55:37Z",
     "kind": "review",
     "text": "VERDICT: findings (1 red, 4 nits)",
     "red": true
    },
    {
     "at": "2026-09-21T15:56:38Z",
     "kind": "review",
     "text": "VERDICT: findings (0 red, 6 nits)",
     "red": false
    },
    {
     "at": "2026-09-21T16:20:52Z",
     "kind": "commit",
     "text": "fix(api): sum the lines before the first write, key idempotency per actor, cap the body wh",
     "sha": "a4d7894"
    },
    {
     "at": "2026-09-21T16:24:27Z",
     "kind": "fix-round",
     "text": "<!-- claude-fix-round -->🔁 Fix round 1/2 (in-chat)."
    },
    {
     "at": "2026-09-21T16:27:06Z",
     "kind": "review",
     "text": "VERDICT: findings (0 red, 2 nits)",
     "red": false
    },
    {
     "at": "2026-09-21T16:28:34Z",
     "kind": "review",
     "text": "VERDICT: clean",
     "red": false
    },
    {
     "at": "2026-09-21T16:29:26Z",
     "kind": "commit",
     "text": "docs(db): migration 0002 comment says carried-over ledger rows never replay (security re-r",
     "sha": "7da2082"
    },
    {
     "at": "2026-09-21T16:29:31Z",
     "kind": "merged",
     "text": "PR #8 merged"
    }
   ],
   "tests": 402
  },
  {
   "issue": 4,
   "title": "The web UI for buyer and approver",
   "events": [
    {
     "at": "2026-09-21T14:17:37Z",
     "kind": "labeled",
     "text": "type:task"
    },
    {
     "at": "2026-09-21T14:18:26Z",
     "kind": "labeled",
     "text": "area:web"
    },
    {
     "at": "2026-09-21T14:18:26Z",
     "kind": "labeled",
     "text": "size:M"
    },
    {
     "at": "2026-09-21T14:18:26Z",
     "kind": "labeled",
     "text": "risk:medium"
    },
    {
     "at": "2026-09-21T14:18:26Z",
     "kind": "labeled",
     "text": "blocked"
    },
    {
     "at": "2026-09-21T16:31:07Z",
     "kind": "labeled",
     "text": "pipeline:build"
    },
    {
     "at": "2026-09-21T16:50:16Z",
     "kind": "commit",
     "text": "feat(web): the buyer and approver pages - server-rendered HTML, one esc(), a cookie sessio",
     "sha": "5d957fb"
    },
    {
     "at": "2026-09-21T16:52:00Z",
     "kind": "pr",
     "text": "The web UI for buyer and approver — server-rendered pages, one esc(), a cookie session (#4"
    },
    {
     "at": "2026-09-21T16:58:50Z",
     "kind": "review",
     "text": "VERDICT: findings (0 red, 5 nits)",
     "red": false
    },
    {
     "at": "2026-09-21T17:00:05Z",
     "kind": "commit",
     "text": "fix(web): the edit action is a styled link, not a button inside an anchor (review nit)",
     "sha": "180f81c"
    },
    {
     "at": "2026-09-21T17:00:11Z",
     "kind": "merged",
     "text": "PR #9 merged"
    }
   ],
   "tests": 434
  },
  {
   "issue": 5,
   "title": "The order outbox, the poll endpoint, the seed script and the README quickstart",
   "events": [
    {
     "at": "2026-09-21T14:17:39Z",
     "kind": "labeled",
     "text": "type:task"
    },
    {
     "at": "2026-09-21T14:18:32Z",
     "kind": "labeled",
     "text": "area:api"
    },
    {
     "at": "2026-09-21T14:18:32Z",
     "kind": "labeled",
     "text": "size:M"
    },
    {
     "at": "2026-09-21T14:18:32Z",
     "kind": "labeled",
     "text": "risk:medium"
    },
    {
     "at": "2026-09-21T14:18:32Z",
     "kind": "labeled",
     "text": "blocked"
    },
    {
     "at": "2026-09-21T16:31:27Z",
     "kind": "labeled",
     "text": "risk:high"
    },
    {
     "at": "2026-09-21T16:31:27Z",
     "kind": "labeled",
     "text": "pipeline:build"
    },
    {
     "at": "2026-09-21T16:45:57Z",
     "kind": "commit",
     "text": "feat(api): the order outbox, the merchant poll and ack, and the seed script",
     "sha": "a810eeb"
    },
    {
     "at": "2026-09-21T16:50:28Z",
     "kind": "commit",
     "text": "docs: the D-011 payload and cursor addendum, D-006 merchant, D-009 ordered, M-004, the REA",
     "sha": "5eba6c1"
    },
    {
     "at": "2026-09-21T16:52:44Z",
     "kind": "commit",
     "text": "test(outbox): pin the payload sum over several lines and the acknowledgement's lifecycle g",
     "sha": "fc109f3"
    },
    {
     "at": "2026-09-21T16:53:29Z",
     "kind": "pr",
     "text": "The order outbox, the merchant poll and ack, the seed script and the README quickstart"
    },
    {
     "at": "2026-09-21T16:58:26Z",
     "kind": "review",
     "text": "VERDICT: findings (1 red, 4 nits)",
     "red": true
    },
    {
     "at": "2026-09-21T17:00:48Z",
     "kind": "review",
     "text": "VERDICT: findings (2 red, 5 nits)",
     "red": true
    },
    {
     "at": "2026-09-21T17:01:56Z",
     "kind": "commit",
     "text": "merge: main (PR #9, the web pages) into feat/issue-5",
     "sha": "7bc2f79"
    },
    {
     "at": "2026-09-21T17:46:52Z",
     "kind": "commit",
     "text": "fix(security): a merchant token reaches the outbox and nothing else (#5 review)",
     "sha": "f4c0d29"
    },
    {
     "at": "2026-09-21T17:46:52Z",
     "kind": "commit",
     "text": "fix(docs): make the README quickstart true, and prove it with a suite (#5 review)",
     "sha": "97abb2b"
    },
    {
     "at": "2026-09-21T17:52:39Z",
     "kind": "fix-round",
     "text": "<!-- claude-fix-round -->🔁 Fix round 1/2 (in-chat)."
    },
    {
     "at": "2026-09-21T17:55:10Z",
     "kind": "review",
     "text": "VERDICT: clean",
     "red": false
    },
    {
     "at": "2026-09-21T17:55:51Z",
     "kind": "review",
     "text": "VERDICT: clean",
     "red": false
    },
    {
     "at": "2026-09-21T17:56:15Z",
     "kind": "merged",
     "text": "PR #10 merged"
    }
   ],
   "tests": 474
  }
 ],
 "built": "2026-09-21T19:52:14.085Z"
};
